# Difference between two dates
Write a program that calculates the difference in days between two dates.
