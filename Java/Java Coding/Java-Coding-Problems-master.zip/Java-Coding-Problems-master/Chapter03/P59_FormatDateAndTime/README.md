# Format date and time
Explain the format pattern for date and time.
