# Calculating age
Write a program that calculates the age of a person.
