# Finding an element in an array
Write several programs that exemplifies how to find the given element (primitive and **Object**) into the given array. Find the index and/or simply check if the value is in the array.
