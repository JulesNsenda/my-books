# Minimum, maximum and average of an array
Write a program that computes the maximum, minimum and average of the given array.
