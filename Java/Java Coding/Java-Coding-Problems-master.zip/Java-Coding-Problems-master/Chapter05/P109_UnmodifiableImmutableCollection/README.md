# Creating unmodifiable/immutable collections
Write several examples that creates unmodifiable and immutable collections.
