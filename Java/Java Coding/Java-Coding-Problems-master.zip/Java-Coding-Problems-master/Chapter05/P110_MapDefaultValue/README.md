# Mapping default value
Write a program that get a value from a **Map** or a default value.
