# Next Greater Element
Write a program that return the Next Greater Element (NGE) for each element of an array.
