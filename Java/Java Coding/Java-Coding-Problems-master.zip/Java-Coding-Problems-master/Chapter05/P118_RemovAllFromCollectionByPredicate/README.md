# Removing all elements of a collection that match a predicate
Write a program that removes all element of a collection that match the given predicate.
