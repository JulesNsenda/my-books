# Merging two Maps
Write a program that merges two given **Map**s.
