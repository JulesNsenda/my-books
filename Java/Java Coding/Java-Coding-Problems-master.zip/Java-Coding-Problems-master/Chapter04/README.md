# Type inference
This chapter includes 21 problems that involves JEP 286, Java Local Variable Type Inference (LVTI), or shortly, the **var** type. 
These problems has been carefully crafted to reveal the best practices and common mistakes involved in using **var**. 
At the end of this chapter, you will have under the tool belt everything you need to know about **var** to push it in production. 
