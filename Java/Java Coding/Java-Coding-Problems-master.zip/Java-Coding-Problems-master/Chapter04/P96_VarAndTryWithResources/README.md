# LVTI and null initializers, instance variable and catch blocks variables
Explain by examples how LVTI can be used in combination with **null** initializers, instance variables and **catch** blocks.
