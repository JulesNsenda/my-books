package modern.challenge;

public class Main {

    public static void main(String[] args) {
 
        // using explicit type
        String pending1 = "pending", processed1 = "processed", deleted1 = "deleted";
        
        // using var
        var pending2 = "pending";
        var processed2 = "processed";
        var deleted2 = "deleted";
    }
    
}
