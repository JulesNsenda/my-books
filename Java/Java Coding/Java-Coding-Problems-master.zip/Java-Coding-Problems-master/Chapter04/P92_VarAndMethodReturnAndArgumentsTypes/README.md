# LVTI and method return and arguments types
Write several snippets of code that exemplifies the usage of LVTI and Java methods return and arguments types.
