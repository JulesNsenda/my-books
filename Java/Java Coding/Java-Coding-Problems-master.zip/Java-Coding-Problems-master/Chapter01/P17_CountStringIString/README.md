# Count string in another string
Write a program that count the occurrences of a given string in another given string.