# Generate all permutations
Write a program that generates all permutations of a given string.