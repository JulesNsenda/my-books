# Reading/writing text files efficiently
Write several programs for exemplifying different approaches for reading and writing a text file in an efficient manner.
