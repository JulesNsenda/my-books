# Searching in big files
Write a program that efficiently searches the given string in a big file.
